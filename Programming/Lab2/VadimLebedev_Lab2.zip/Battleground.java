import ru.ifmo.se.pokemon. *;
import static java.lang.Math. *;

public class Battleground {
	public static void main(String[] args){
		Battle battle = new Battle();
		battle.addAlly(new Mimikyu("Naruto", 17));
			battle.addAlly(new Phanpy("Sakura", 13));
			battle.addAlly(new Donphan("Sai", 15));
			battle.addFoe(new Togepi("Sasuke", 17));
			battle.addFoe(new Togetic("Jugo", 13));
			battle.addFoe(new Togekiss("Suigetsu", 15));
			battle.go();
	}
}


		