import  ru.ifmo.se.pokemon. * ;

public class Donphan extends Phanpy {
	public Donphan (String name, int lvl ) {
		super (имя, уровень);
		setStats ( 90, 120, 120, 60, 60, 50 );
		setType ( Type.GROUND );
		setMove ( new RockSlide(), new RockTomb(), new Facade(), new ScaryFace() );
	}
}

class ScaryFace extends StatusMove {
	public ScaryFace () {
		super (Type.NORMAL, 0, 1.0);
	}
	
	protected void applyOppEffects(Pokemon p) {
		p.setMod(Stat.SPEED, -2);
	}
}