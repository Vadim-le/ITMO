import  ru.ifmo.se.pokemon. * ;

public class Togetic extends Togepi {
	public Togetic (String name, int lvl ) {
		super (имя, уровень);
		setStats ( 55, 40, 85, 80, 105, 40 );
		setType ( Type.FAIRY, Type.FLYING );
		setMove ( new Psychic(), new ThunderWave(), new DoubleEdge() )